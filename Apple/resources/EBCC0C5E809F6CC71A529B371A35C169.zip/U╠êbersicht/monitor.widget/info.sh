# get information of CPU and Memory usage
ps aux  | awk 'BEGIN { sum = 0 ; sum2 = 0 }  { sum += $3; sum2 += $4 }; END { print sum"\n"sum2 }'

# get information of disk usage
df -H | awk 'NR == 2 {print $5}' | sed -e "s/\%//g"

# get information of PC battery usage
pmset -g batt | egrep -E "([0-9]+\%)" -o --colour=auto | cut -f1 -d';' | sed -e "s/\%//g"

# get information of mouse battery usage
system_profiler SPBluetoothDataType | grep -E 'Battery|Minor Type' | sed 's/Minor Type://g' | sed 's/Battery Level://g' |sed 's/Unknown//g' |sed -e 's/^[ \t]*//' | paste -d' ' - - | sed -e "s/%//g" | sed -e "s/Mouse //g"